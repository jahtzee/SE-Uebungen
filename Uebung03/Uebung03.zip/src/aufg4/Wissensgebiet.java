/**
 * 
 */
package aufg4;

/**
 * @author Jan Zimmer
 * last modified 28.10.2022
 */
public class Wissensgebiet {

	private String name;
	
	public Wissensgebiet(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}

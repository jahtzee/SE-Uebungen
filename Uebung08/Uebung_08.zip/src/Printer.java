/**
 * @author Jan Zimmer
 * last modified 05.01.2023
 */
public class Printer extends Device {
	public String printerId;
	
	public Printer(String printerId) {
		this.printerId = printerId;
	}
}

/**
 * @author Jan Zimmer
 * last modified 05.01.2023
 * 
 * Abstract device stub
 */
public abstract class Device {

}
